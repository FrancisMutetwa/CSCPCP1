package MonteCarloMini;

/* Francis Mutetwa
 * Searcher class that lands somewhere random on the surfaces and 
 * then moves downhill, stopping at the local minimum.
 * The class then does a Recursive action thereby making the process of finding the local minimum parallel
 * When all the threads are done finding their local minimum, a global minimum will be returned from this pool of threads.
 */
//import java.util.Random;
import java.util.concurrent.RecursiveAction;
import java.util.Arrays;

public class SearchParallel {
	private int id;				// Searcher identifier
	private int pos_row, pos_col;		// Position in the grid
	private int steps; //number of steps to end of search
	private boolean stopped;			// Did the search hit a previous trail?
	static int f = -1;
	static int min = Integer.MAX_VALUE;
	int SEQUENTIAL_CUTOFF = 150000;

	private TerrainArea terrain;
	enum Direction {
		STAY_HERE,
	    LEFT,
	    RIGHT,
	    UP,
	    DOWN
	  }

	public SearchParallel(int id, int pos_row, int pos_col, TerrainArea terrain) {
		this.id = id;
		this.pos_row = pos_row; //randomly allocated
		this.pos_col = pos_col; //randomly allocated
		this.terrain = terrain;
		this.stopped = false;
	}
	
	public SearchParallel(){


	}


	public int find_valleys() {	
		int height=Integer.MAX_VALUE;
		Direction next = Direction.STAY_HERE;
		while(terrain.visited(pos_row, pos_col)==0) { // stop when hit existing path
			height=terrain.get_height(pos_row, pos_col);
			terrain.mark_visited(pos_row, pos_col, id); //mark current position as visited
			steps++;
			next = terrain.next_step(pos_row, pos_col);
			switch(next) {
				case STAY_HERE: return height; //found local valley
				case LEFT: 
					pos_row--;
					break;
				case RIGHT:
					pos_row=pos_row+1;
					break;
				case UP: 
					pos_col=pos_col-1;
					break;
				case DOWN: 
					pos_col=pos_col+1;
					break;
			}
		}
		stopped=true;
		return height;
	}

	public int getID() {
		return id;
	}

	public int getPos_row() {
		return pos_row;
	}

	public int getPos_col() {
		return pos_col;
	}

	public int getSteps() {
		return steps;
	}
	public boolean isStopped() {
		return stopped;
	}

	public int F(){
		return f;
	}

	public int getMin(){
		return min;
	}


	public class SearchAction extends RecursiveAction{
		
		SearchParallel [] searches;
		int local_min;

		public SearchAction(SearchParallel[] searches){
			this.searches = searches;
		}

		

		public void serialSearch(){
			for (int i = 0; i < searches.length; i++){
					local_min = searches[i].find_valleys();
					if((!searches[i].isStopped())&&(local_min<SearchParallel.min)){
						SearchParallel.min = local_min;
						f = searches[i].getID();
					}
				}
		}

		public void compute(){
			if (searches.length <SEQUENTIAL_CUTOFF){
				serialSearch();
			}
			else{
				SearchParallel[] left = Arrays.copyOfRange(searches, 0, searches.length/2);
				SearchAction Left = new SearchAction(left);
				SearchParallel[] right = Arrays.copyOfRange(searches, searches.length/2, searches.length);
				SearchAction Right = new SearchAction(right);
				//Left.fork();
				//Right.compute();
				//Left.join();
				
				invokeAll(Left, Right);

			}
		}
	}

	
}
